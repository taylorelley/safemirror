"""Main module for clean-package."""
