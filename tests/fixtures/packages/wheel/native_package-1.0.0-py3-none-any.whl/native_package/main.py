"""Main module for native-package."""
