from setuptools import setup

setup(
    name="setuppy-package",
    version="1.0.0",
    packages=["setuppy_package"],
)
