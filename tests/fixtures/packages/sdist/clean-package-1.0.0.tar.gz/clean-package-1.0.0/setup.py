from setuptools import setup

setup(
    name="clean-package",
    version="1.0.0",
    packages=["clean_package"],
)
