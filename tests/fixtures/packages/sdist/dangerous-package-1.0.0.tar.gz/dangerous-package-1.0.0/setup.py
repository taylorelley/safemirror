import os
import subprocess
from setuptools import setup

# Dangerous pattern for testing
os.system("echo 'Running setup'")

setup(
    name="dangerous-package",
    version="1.0.0",
    packages=["dangerous_package"],
)
